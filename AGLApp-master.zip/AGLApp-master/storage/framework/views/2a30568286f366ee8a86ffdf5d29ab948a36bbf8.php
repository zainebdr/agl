<?php $__env->startSection('content'); ?>
    <h1>Listes des Demandes</h1>
    <?php if(count($demands) > 0): ?>
        <?php $__currentLoopData = $demands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card mb-5">
            <div class="card-header">
              <?php echo e($demand->item->subject->name); ?>

        

            </div>
            <div class="card-body">
              <h5 class="card-title">Item: <?php echo e($demand->item->name); ?></h5>
              <p class="card-text">Dead Line: <?php echo e($demand->dl); ?></p>
              <hr>
    
              <a href="<?php echo e(route('applicant.demands.show', $demand)); ?>" class="btn btn-primary">Check this demand</a>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    <?php else: ?>
        <h2 class="text-center">Aucune demande a traiter</h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\agl-master (3)\agl-master\AGLApp-master\AGLApp-master\resources\views/applicant/demands/index.blade.php ENDPATH**/ ?>