<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('giver-role')): ?>
                        <a href="<?php echo e(route('giver.donations.subject_choice')); ?>" class="btn btn-primary">Create Donation</a> 
                    <?php endif; ?>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicant-role')): ?>
                        <a href="<?php echo e(route('applicant.demands.subject_choice')); ?>" class="btn btn-primary">Create Demand</a>        
                    <?php endif; ?>
                    
                    
                    <a href="<?php echo e(route('giver.donations.subject_choice')); ?>" class="btn btn-success ml-3 float-right">Check Delevery</a>    
                    <a href="<?php echo e(route('user.reclamations.create')); ?>" class="btn btn-success ml-3 float-right">Add Reclamation</a>    
                   
    
                    <nav aria-label="breadcrumb" class="mt-5">
                        <ol class="breadcrumb">
                          <li class="breadcrumb-item active" aria-current="page">Reservations</li>
                        </ol>
                    </nav>
                    
                    
                        <table class="table mt-2">
                            <thead>
                                <tr>
                                    <th scope="col">Created at</th>
                                    <th scope="col">Check demand</th>
                                    <th scope="col">Check donation</th>
                                    <th scope="col">Verify Reservation</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                
                                    <tr>
                                        <td><?php echo e($reservation->demand_created_at); ?></td>
                                        
                                        <td>
                                            <a href="<?php echo e(route('applicant.demands.show', $reservation->demand_id)); ?>"><button type="button" class="btn btn-primary float-left">Check Demand</button></a>    
                                        </td>
                                        
                                        <td>
                                            <a href="<?php echo e(route('giver.donations.show', $reservation->donation_id)); ?>"><button type="button" class="btn btn-primary float-left">Check Donation</button></a>               
                                        </td>
                                        
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['giver-role', 'admin-role'])): ?>
                                                <form action="<?php echo e(route('applicant.reservations.update', $reservation->reservation_id)); ?>" method="POST" class="float-left mr-3">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo e(method_field('PUT')); ?>

                                                    <button type="submit" class="btn btn-success">Confirm</button>
                                                </form>
                                            <?php endif; ?>
                                                
                                            
                                            <form action="<?php echo e(route('applicant.reservations.destroy', $reservation->reservation_id)); ?>" method="POST" class="float-right">
                                                <?php echo csrf_field(); ?>
                                                <?php echo e(method_field('DELETE')); ?>

                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>                                         
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>   
                    
                    
                   
                    
                </div>
            </div>
        </div>
        
        
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <span style="font-size:24px">Notifications</span> 
                    </div>
                        
                    <div class="card-body">
                        
                        <?php if(count($accepted_reservations) > 0): ?>
                            <?php $__currentLoopData = $accepted_reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accepted_reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card mb-3">
                                    <div class="card-header">
                                    Reservation Created at : <?php echo e($accepted_reservation->reservation_created_at); ?>

                                    </div>
                                    <div class="card-body">
                                    <blockquote class="blockquote mb-0">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicant-role')): ?>
                                            <p>Your demand has been accepted   <a class="btn btn-dark" href="<?php echo e(route('applicant.demands.show', $accepted_reservation->demand_id)); ?>">Check</a></p>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['giver-role', 'admin-role'])): ?>
                                            <p>Your have accepted this demand  <a class="btn btn-dark" href="<?php echo e(route('applicant.demands.show', $accepted_reservation->demand_id)); ?>">Check</a></p>
                                        <?php endif; ?>
                                        
                                        <?php if( ($accepted_reservation->giver_delivery_man == -1 && $accepted_reservation->applicant_delivery_man == -1) || ($accepted_reservation->giver_delivery_man == 0 && $accepted_reservation->applicant_delivery_man == -1) ): ?>
                                            <p>Pleas click here to check the reservation delevery info  <a class="btn btn-dark" href="<?php echo e(route('applicant.reservations.show', $accepted_reservation->reservation_id)); ?>">Check</a></p>    
                                        <?php else: ?>
                                            <?php if($accepted_reservation->giver_delivery_man == 1 || $accepted_reservation->applicant_delivery_man == 1): ?>
                                                <p>Your delevery is ready click here for more info <a class="btn btn-dark" href="<?php echo e(route('contact.delivery.show', $accepted_reservation->reservation_id)); ?>">Check</a></p>
                                            <?php else: ?>
                                                <?php if($accepted_reservation->giver_delivery_man == 0 && $accepted_reservation->applicant_delivery_man == 0): ?>
                                                    <p>
                                                        We will handle the delevery process click here for more info  
                                                        <form action="<?php echo e(route('contact.delivery.store')); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input style="display:none" type="text" class="form-control" name="reservation_id" value="<?php echo e($accepted_reservation->reservation_id); ?>" required >    
                                                            <button type="submit" class="btn btn-dark">Delevery</button>
                                                        </form>    
                                                    </p>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                    <footer class="blockquote-footer">Accepted at <cite title="Source Title"><?php echo e($accepted_reservation->updated_at); ?></cite></footer>
                                    </blockquote>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                          
                        <?php else: ?>
                                <div class="alert alert-primary" role="alert">
                                    No New Notifications
                                </div>
                        
                        <?php endif; ?>                      
                            
                    </div>
                </div>
            </div>
     
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\AGLApp-master\AGLApp-master\resources\views/home.blade.php ENDPATH**/ ?>