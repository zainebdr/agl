<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit a Donation</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('giver.donations.update', $donation)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>


                        <div class="form-group row">
                            <label for="items" class="col-md-4 col-form-label text-md-right">Items</label>

                            <div class="col-md-6">
                                <select class="form-control" id="item" name="item">
                                    <option value="none">Select Item</option>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="descreption" class="col-md-4 col-form-label text-md-right">Descreption</label>

                            <div class="col-md-6">
                                <textarea class="form-control" name="descreption" id="descreption" rows="3" required autofocus><?php echo e($donation->description); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="amount" class="col-md-4 col-form-label text-md-right">Amount</label>

                            <div class="col-md-6">
                            <input id="qty" type="text" class="form-control" name="qty" value="<?php echo e($donation->qty); ?>" required >    
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="location" class="col-md-4 col-form-label text-md-right">Location</label>

                            <div class="col-md-6">
                                <input id="location" type="text" class="form-control" name="location" value="<?php echo e($donation->location); ?>" required >    
                            </div>
                        </div>

                        <div class="form-group row">
                        <label for="availability" class="col-md-4 col-form-label text-md-right">Availability</label>

                            <div class="col-md-6">
                                <input id="availability" type="text" class="form-control" name="availability" value="<?php echo e($donation->availability); ?>" required >    
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="followed" class="col-md-4 col-form-label text-md-right">Followed</label>

                            <div class="col-md-6">
                                <div class="form-check">
                                    <input type="radio" name="followed" value="1"
                                    <?php if($donation->followed == 1): ?>
                                        checked
                                    <?php endif; ?>
                                    >
                                    <label>Yes</label>
                                </div>
                                <div class="form-check">
                                    <input type="radio" name="followed" value="0"
                                    <?php if($donation->followed == 0): ?>
                                        checked
                                    <?php endif; ?>
                                    >
                                    <label>No</label>
                                </div>
                                
                            </div>
                        </div>

                    <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Update Donation
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Projet AGL\project-agl-master\AGLApp-master\resources\views/giver/donations/edit.blade.php ENDPATH**/ ?>