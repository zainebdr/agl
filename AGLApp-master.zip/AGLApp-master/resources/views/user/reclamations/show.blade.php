@extends('layouts.app')

@section('content')
@can('admin-role')
    <a href="{{ route('user.reclamations.index') }}" class="btn btn-danger">Go Back</a>
@endcan  
@canany(['applicant-role','giver-role','delivery-man-role'])
    <a href="{{ route('user.reclamations.index_rec') }}" class="btn btn-danger">Go Back</a>
@endcanany  
    <h1>Type : {{ $reclamation->type }}</h1>
    <h4>By : {{ $reclamation->user_id}}</h4>
    @if ($reclamation->type != 'Technique')
    <h4>Delivery number : {{ $reclamation->delivery_id}}</h4>
@endif
    <h4>Subjcet : {{ $reclamation->sujet}}</h4>
    <div>
       Description: {!!$reclamation->description!!}
    </div>
    
    <hr>
    <small>Written on {{ $reclamation->created_at }}<br></small>
    </hr>
    @auth
       
            @if (Auth::user()->id == $reclamation->user_id)
                <a href="{{ route('user.reclamations.edit', $reclamation) }}"><button type="button" class="btn btn-success btn-lg float-left">Edit</button></a>
                <form action="{{ route('user.reclamations.destroy', $reclamation) }}" method="POST" class="float-right">
                    @csrf
                    {{method_field('DELETE')}}
                    <button type="submit" class="btn btn-lg btn-secondary">Delete</button>
                </form>    
         
       
        @endif
            
            
    @endauth
    
@endsection