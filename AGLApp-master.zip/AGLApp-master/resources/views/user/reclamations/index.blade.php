@extends('layouts.app')

@section('content')
    <h1>Listes des Reclamations</h1>
    @if (count($reclamations) > 0)
        @foreach($reclamations as $reclamation)
          <div class="card mb-5">
            <div class="card-header">
             {{ $reclamation->item->subject->name }}
            </div>
            <div class="card-body">
              <h5 class="card-title">Item: {{ $reclamation->item->name }}</h5>
              <p class="card-text">Availability: {{ $donation->availability }}</p>
              <hr>
    
              <a href="{{ route('user.reclamations.show', $reclamation) }}" class="btn btn-primary">Check this reclamation</a>
            </div>
          </div>
        @endforeach
      
    @else
        <h2 class="text-center">Aucune Reclamation</h2>
    @endif
@endsection